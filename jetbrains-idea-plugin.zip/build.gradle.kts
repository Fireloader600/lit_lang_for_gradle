plugins {
    id("java")
    // 2.x 插件 ID。2.19.0 对 2026.2 平台支持最好
    id("org.jetbrains.intellij.platform") version "2.19.0"
}

group   = "com.lithium"
version = "0.1.0"

repositories {
    mavenCentral()

    // JetBrains 官方缓存镜像，加速 IDE 依赖下载
    maven("https://cache-redirector.jetbrains.com/intellij-repository/releases")
    maven("https://cache-redirector.jetbrains.com/intellij-dependencies")

    intellijPlatform {
        defaultRepositories()
    }
}

// ============================================================
// 编译设置
//   - sourceCompatibility / targetCompatibility 只决定"字节码目标"
//   - 编译使用的 JDK 由 IntelliJ Platform Gradle Plugin 根据目标 IDE
//     自动决定：2026.2.1 需要 JDK 25，2025.x 需要 JDK 21
//   - 若本机没有 JDK 25：
//       a) 装一个 JDK 25（清华镜像有），并在 gradle.properties 里加
//          org.gradle.java.installations.paths=C\:\\Java\\jdk-25
//       或
//       b) 把下面的 intellijIdea("2026.2.1") 改成 intellijIdea("2025.2")，
//          并把 ideaVersion.sinceBuild 改成 "252"
// ============================================================
java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

tasks.withType<JavaCompile>().configureEach {
    options.release.set(17)
    options.encoding = "UTF-8"
}

// ============================================================
// 目标 IntelliJ 平台
// ============================================================
dependencies {
    intellijPlatform {
        intellijIdea("2025.2")  // 从 2025.3 开始统一使用这个
    }
}

// ============================================================
// 插件配置
// ============================================================
intellijPlatform {
    // 关闭"可搜索选项"生成，加快构建
    buildSearchableOptions = false

    pluginConfiguration {
        version = project.version.toString()

        ideaVersion {
            // 2026.2.1 对应的分支号
            sinceBuild = "252"
            // 不限制上限，自动兼容未来 IDE 版本
            untilBuild = provider { null }
        }
    }

    // 签名（本地开发不需要，只在 CI 里通过环境变量启用）
    signing {
        certificateChain = providers.environmentVariable("CERTIFICATE_CHAIN")
        privateKey       = providers.environmentVariable("PRIVATE_KEY")
        password         = providers.environmentVariable("PRIVATE_KEY_PASSWORD")
    }

    // 发布到 JetBrains Marketplace（本地开发不需要）
    publishing {
        token = providers.environmentVariable("PUBLISH_TOKEN")
    }
}