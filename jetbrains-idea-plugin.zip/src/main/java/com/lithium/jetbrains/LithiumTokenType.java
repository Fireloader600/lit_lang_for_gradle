package com.lithium.jetbrains;

import com.intellij.psi.tree.IElementType;
import org.jetbrains.annotations.NotNull;

public final class LithiumTokenType extends IElementType {
    public LithiumTokenType(@NotNull String debugName) {
        super(debugName, LithiumLanguage.INSTANCE);
    }
    @Override public String toString() { return "Lithium:" + super.toString(); }
}