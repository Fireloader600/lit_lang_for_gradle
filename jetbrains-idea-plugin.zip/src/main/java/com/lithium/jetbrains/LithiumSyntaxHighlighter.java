package com.lithium.jetbrains;

import com.intellij.lexer.Lexer;
import com.intellij.openapi.editor.DefaultLanguageHighlighterColors;
import com.intellij.openapi.editor.HighlighterColors;
import com.intellij.openapi.editor.colors.TextAttributesKey;
import com.intellij.openapi.fileTypes.SyntaxHighlighterBase;
import com.intellij.psi.TokenType;
import com.intellij.psi.tree.IElementType;
import org.jetbrains.annotations.NotNull;

import static com.intellij.openapi.editor.colors.TextAttributesKey.createTextAttributesKey;

public class LithiumSyntaxHighlighter extends SyntaxHighlighterBase {

    public static final TextAttributesKey KEYWORD =
        createTextAttributesKey("LITHIUM_KEYWORD", DefaultLanguageHighlighterColors.KEYWORD);
    public static final TextAttributesKey IDENTIFIER =
        createTextAttributesKey("LITHIUM_IDENTIFIER", DefaultLanguageHighlighterColors.IDENTIFIER);
    public static final TextAttributesKey NUMBER =
        createTextAttributesKey("LITHIUM_NUMBER", DefaultLanguageHighlighterColors.NUMBER);
    public static final TextAttributesKey STRING =
        createTextAttributesKey("LITHIUM_STRING", DefaultLanguageHighlighterColors.STRING);
    public static final TextAttributesKey COMMENT =
        createTextAttributesKey("LITHIUM_COMMENT", DefaultLanguageHighlighterColors.LINE_COMMENT);
    public static final TextAttributesKey OPERATOR =
        createTextAttributesKey("LITHIUM_OPERATOR", DefaultLanguageHighlighterColors.OPERATION_SIGN);
    public static final TextAttributesKey BRACES =
        createTextAttributesKey("LITHIUM_BRACES", DefaultLanguageHighlighterColors.BRACES);
    public static final TextAttributesKey SEMI =
        createTextAttributesKey("LITHIUM_SEMI", DefaultLanguageHighlighterColors.SEMICOLON);
    public static final TextAttributesKey COMMA =
        createTextAttributesKey("LITHIUM_COMMA", DefaultLanguageHighlighterColors.COMMA);
    public static final TextAttributesKey DOT =
        createTextAttributesKey("LITHIUM_DOT", DefaultLanguageHighlighterColors.DOT);

    private static final TextAttributesKey[] KW_KEYS       = { KEYWORD };
    private static final TextAttributesKey[] IDENT_KEYS    = { IDENTIFIER };
    private static final TextAttributesKey[] NUM_KEYS      = { NUMBER };
    private static final TextAttributesKey[] STRING_KEYS   = { STRING };
    private static final TextAttributesKey[] COMMENT_KEYS  = { COMMENT };
    private static final TextAttributesKey[] OP_KEYS       = { OPERATOR };
    private static final TextAttributesKey[] BRACE_KEYS    = { BRACES };
    private static final TextAttributesKey[] SEMI_KEYS     = { SEMI };
    private static final TextAttributesKey[] COMMA_KEYS    = { COMMA };
    private static final TextAttributesKey[] DOT_KEYS      = { DOT };
    private static final TextAttributesKey[] EMPTY         = new TextAttributesKey[0];

    @NotNull @Override
    public Lexer getHighlightingLexer() { return new LithiumLexer(); }

    @NotNull @Override
    public TextAttributesKey[] getTokenHighlights(IElementType tokenType) {
        if (tokenType == LithiumTokenTypes.KEYWORD)  return KW_KEYS;
        if (tokenType == LithiumTokenTypes.IDENT)    return IDENT_KEYS;
        if (tokenType == LithiumTokenTypes.NUMBER)   return NUM_KEYS;
        if (tokenType == LithiumTokenTypes.STRING)   return STRING_KEYS;
        if (tokenType == LithiumTokenTypes.COMMENT)  return COMMENT_KEYS;
        if (tokenType == LithiumTokenTypes.OPERATOR) return OP_KEYS;
        if (tokenType == LithiumTokenTypes.BRACE)    return BRACE_KEYS;
        if (tokenType == LithiumTokenTypes.SEMI)     return SEMI_KEYS;
        if (tokenType == LithiumTokenTypes.COMMA)    return COMMA_KEYS;
        if (tokenType == LithiumTokenTypes.DOT)      return DOT_KEYS;
        return EMPTY;
    }
}