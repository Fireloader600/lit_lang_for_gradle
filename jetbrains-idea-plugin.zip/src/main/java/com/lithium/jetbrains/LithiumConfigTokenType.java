package com.lithium.jetbrains;

import com.intellij.psi.tree.IElementType;
import org.jetbrains.annotations.NotNull;

public final class LithiumConfigTokenType extends IElementType {
    public LithiumConfigTokenType(@NotNull String debugName) {
        super(debugName, LithiumConfigLanguage.INSTANCE);
    }
    @Override public String toString() { return "LithiumConfig:" + super.toString(); }
}