package com.lithium.jetbrains;

import com.intellij.openapi.editor.colors.TextAttributesKey;
import com.intellij.openapi.fileTypes.SyntaxHighlighter;
import com.intellij.openapi.options.colors.AttributesDescriptor;
import com.intellij.openapi.options.colors.ColorDescriptor;
import com.intellij.openapi.options.colors.ColorSettingsPage;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.util.Map;

public final class LithiumColorSettingsPage implements ColorSettingsPage {

    private static final AttributesDescriptor[] DESCRIPTORS = new AttributesDescriptor[]{
        new AttributesDescriptor("Keyword",      LithiumSyntaxHighlighter.KEYWORD),
        new AttributesDescriptor("Identifier",   LithiumSyntaxHighlighter.IDENTIFIER),
        new AttributesDescriptor("Number",       LithiumSyntaxHighlighter.NUMBER),
        new AttributesDescriptor("String",       LithiumSyntaxHighlighter.STRING),
        new AttributesDescriptor("Line comment", LithiumSyntaxHighlighter.COMMENT),
        new AttributesDescriptor("Operator",     LithiumSyntaxHighlighter.OPERATOR),
        new AttributesDescriptor("Braces",       LithiumSyntaxHighlighter.BRACES),
        new AttributesDescriptor("Semicolon",    LithiumSyntaxHighlighter.SEMI),
        new AttributesDescriptor("Comma",        LithiumSyntaxHighlighter.COMMA),
        new AttributesDescriptor("Dot",          LithiumSyntaxHighlighter.DOT),
    };

    @Nullable @Override public Icon getIcon() { return null; }

    @NotNull @Override
    public SyntaxHighlighter getHighlighter() { return new LithiumSyntaxHighlighter(); }

    @NotNull @Override
    public String getDemoText() {
        return """
            # Lithium demo
            import lit;

            lit(){
                let name = "Lithium";
                out("Hello, " + name + "!");

                let i = 1;
                while i <= 3 {
                    out(i);
                    i = i + 1;
                }

                end 0;
            }
            """;
    }

    @Nullable @Override
    public Map<String, TextAttributesKey> getAdditionalHighlightingTagToDescriptorMap() {
        return null;
    }

    @NotNull @Override public AttributesDescriptor[] getAttributeDescriptors() { return DESCRIPTORS; }
    @NotNull @Override public ColorDescriptor[]      getColorDescriptors()     { return ColorDescriptor.EMPTY_ARRAY; }
    @NotNull @Override public String                 getDisplayName()          { return "Lithium"; }
}