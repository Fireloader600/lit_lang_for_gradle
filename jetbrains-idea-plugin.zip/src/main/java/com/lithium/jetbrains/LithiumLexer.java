package com.lithium.jetbrains;

import com.intellij.lexer.LexerBase;
import com.intellij.psi.TokenType;
import com.intellij.psi.tree.IElementType;
import org.jetbrains.annotations.NotNull;

import java.util.Set;

public final class LithiumLexer extends LexerBase {

    private static final Set<String> KEYWORDS = Set.of(
        "import", "let", "if", "else", "while", "end", "fn", "return"
    );
    private static final Set<String> LITERALS = Set.of("true", "false", "null");
    private static final Set<String> BUILTINS = Set.of(
        "out", "print", "len", "str", "num", "type", "bool",
        "upper", "lower", "split", "contains", "push", "range", "exit", "assert",
        "lit", "config"
    );

    private CharSequence buffer = "";
    private int start, end, pos, state;
    private IElementType token;

    @Override
    public void start(@NotNull CharSequence buf, int s, int e, int initState) {
        buffer = buf; start = s; end = e; pos = s; state = initState;
        advance();
    }

    @Override public int getState()               { return state; }
    @Override public IElementType getTokenType()  { return token; }
    @Override public int getTokenStart()          { return pos; }
    @Override public int getTokenEnd()            { return start; }

    @Override
    public void advance() {
        pos = start;
        if (start >= end) { token = null; return; }

        char c = buffer.charAt(start);

        // 注释
        if (c == '#') {
            while (start < end && buffer.charAt(start) != '\n') start++;
            token = LithiumTokenTypes.COMMENT;
            return;
        }
        if (c == '/' && start + 1 < end && buffer.charAt(start + 1) == '/') {
            while (start < end && buffer.charAt(start) != '\n') start++;
            token = LithiumTokenTypes.COMMENT;
            return;
        }

        // 空白
        if (Character.isWhitespace(c)) {
            while (start < end && Character.isWhitespace(buffer.charAt(start))) start++;
            token = TokenType.WHITE_SPACE;
            return;
        }

        // 标识符 / 关键字
        if (Character.isLetter(c) || c == '_') {
            int s = start;
            while (start < end && (Character.isLetterOrDigit(buffer.charAt(start)) || buffer.charAt(start) == '_')) start++;
            String w = buffer.subSequence(s, start).toString();
            if (KEYWORDS.contains(w) || LITERALS.contains(w) || BUILTINS.contains(w)) {
                token = LithiumTokenTypes.KEYWORD;
            } else {
                token = LithiumTokenTypes.IDENT;
            }
            return;
        }

        // 数字
        if (Character.isDigit(c)) {
            while (start < end && (Character.isDigit(buffer.charAt(start)) || buffer.charAt(start) == '.')) start++;
            token = LithiumTokenTypes.NUMBER;
            return;
        }

        // 字符串
        if (c == '"') {
            start++;
            while (start < end && buffer.charAt(start) != '"') {
                if (buffer.charAt(start) == '\\' && start + 1 < end) start++;
                start++;
            }
            if (start < end) start++;
            token = LithiumTokenTypes.STRING;
            return;
        }

        // 括号
        if (c == '{' || c == '}' || c == '(' || c == ')' || c == '[' || c == ']') {
            start++;
            token = LithiumTokenTypes.BRACE;
            return;
        }

        // 分隔符
        if (c == ';') { start++; token = LithiumTokenTypes.SEMI; return; }
        if (c == ',') { start++; token = LithiumTokenTypes.COMMA; return; }
        if (c == '.') { start++; token = LithiumTokenTypes.DOT; return; }

        // 运算符 / 其他
        start++;
        token = LithiumTokenTypes.OPERATOR;
    }

    @Override public @NotNull CharSequence getBufferSequence() { return buffer; }
    @Override public int getBufferEnd() { return end; }
}