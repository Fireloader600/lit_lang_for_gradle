package com.lithium.jetbrains;

import com.intellij.lang.annotation.AnnotationHolder;
import com.intellij.lang.annotation.Annotator;
import com.intellij.lang.annotation.HighlightSeverity;
import com.intellij.psi.PsiElement;
import org.jetbrains.annotations.NotNull;

/**
 * 简单检查：给出 "lit(){ ... }" 结构缺失的提示。
 * 可根据需要扩展为更完整的语法检查。
 */
public final class LithiumAnnotator implements Annotator {

    @Override
    public void annotate(@NotNull PsiElement element, @NotNull AnnotationHolder holder) {
        String text = element.getText();
        if (text == null) return;

        // 检测常见错误：'end' 后没有代码
        if ("end".equals(text)) {
            PsiElement next = element.getNextSibling();
            while (next != null && next.getText().isBlank()) next = next.getNextSibling();
            if (next == null) {
                holder.newAnnotation(HighlightSeverity.WARNING, "end 后缺少退出码")
                      .range(element)
                      .create();
            }
        }
    }
}