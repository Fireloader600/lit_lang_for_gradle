package com.lithium.jetbrains;

import com.intellij.lang.Language;

public final class LithiumConfigLanguage extends Language {
    public static final LithiumConfigLanguage INSTANCE = new LithiumConfigLanguage();
    private LithiumConfigLanguage() { super("LithiumConfig"); }
}