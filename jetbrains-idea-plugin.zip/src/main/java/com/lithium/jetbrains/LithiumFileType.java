package com.lithium.jetbrains;

import com.intellij.openapi.fileTypes.LanguageFileType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;

public final class LithiumFileType extends LanguageFileType {
    public static final LithiumFileType INSTANCE = new LithiumFileType();

    private LithiumFileType() { super(LithiumLanguage.INSTANCE); }

    @NotNull @Override public String getName()             { return "Lithium File"; }
    @NotNull @Override public String getDescription()      { return "Lithium 源文件"; }
    @NotNull @Override public String getDefaultExtension() { return "lit"; }
    @Nullable @Override public Icon getIcon()              { return null; }
}