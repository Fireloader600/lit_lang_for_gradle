package com.lithium.jetbrains;

import com.intellij.psi.tree.IElementType;

public final class LithiumTokenTypes {
    private LithiumTokenTypes() {}

    public static final IElementType KEYWORD  = new LithiumTokenType("KEYWORD");
    public static final IElementType IDENT    = new LithiumTokenType("IDENT");
    public static final IElementType NUMBER   = new LithiumTokenType("NUMBER");
    public static final IElementType STRING   = new LithiumTokenType("STRING");
    public static final IElementType COMMENT  = new LithiumTokenType("COMMENT");
    public static final IElementType OPERATOR = new LithiumTokenType("OPERATOR");
    public static final IElementType BRACE    = new LithiumTokenType("BRACE");
    public static final IElementType SEMI     = new LithiumTokenType("SEMI");
    public static final IElementType COMMA    = new LithiumTokenType("COMMA");
    public static final IElementType DOT      = new LithiumTokenType("DOT");
}