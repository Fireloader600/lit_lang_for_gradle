package com.lithium.jetbrains;

import com.intellij.lexer.LexerBase;
import com.intellij.psi.TokenType;
import com.intellij.psi.tree.IElementType;
import org.jetbrains.annotations.NotNull;

public final class LithiumConfigLexer extends LexerBase {

    private CharSequence buffer = "";
    private int start, end, pos, state;
    private IElementType token;

    @Override
    public void start(@NotNull CharSequence buf, int s, int e, int initState) {
        buffer = buf; start = s; end = e; pos = s; state = initState;
        advance();
    }

    @Override public int getState()               { return state; }
    @Override public IElementType getTokenType()  { return token; }
    @Override public int getTokenStart()          { return pos; }
    @Override public int getTokenEnd()            { return start; }

    @Override
    public void advance() {
        pos = start;
        if (start >= end) { token = null; return; }

        char c = buffer.charAt(start);

        if (c == '#') {
            while (start < end && buffer.charAt(start) != '\n') start++;
            token = LithiumConfigTokenTypes.COMMENT;
            return;
        }

        if (Character.isWhitespace(c)) {
            while (start < end && Character.isWhitespace(buffer.charAt(start))) start++;
            token = TokenType.WHITE_SPACE;
            return;
        }

        // 字符串
        if (c == '"') {
            start++;
            while (start < end && buffer.charAt(start) != '"') {
                if (buffer.charAt(start) == '\\' && start + 1 < end) start++;
                start++;
            }
            if (start < end) start++;
            token = LithiumConfigTokenTypes.STRING;
            return;
        }

        // 数字
        if (Character.isDigit(c) || ((c == '-' || c == '+') && start + 1 < end && Character.isDigit(buffer.charAt(start + 1)))) {
            if (c == '-' || c == '+') start++;
            while (start < end && (Character.isDigit(buffer.charAt(start)) || buffer.charAt(start) == '.')) start++;
            token = LithiumConfigTokenTypes.NUMBER;
            return;
        }

        // 标识符（键或字面量 true/false/null）
        if (Character.isLetter(c) || c == '_') {
            int s = start;
            while (start < end && (Character.isLetterOrDigit(buffer.charAt(start)) || buffer.charAt(start) == '_' || buffer.charAt(start) == '-')) start++;
            String w = buffer.subSequence(s, start).toString();
            if (w.equals("true") || w.equals("false") || w.equals("null")) {
                token = LithiumConfigTokenTypes.LITERAL;
            } else {
                token = LithiumConfigTokenTypes.KEY;
            }
            return;
        }

        if (c == '{' || c == '}' || c == '(' || c == ')') {
            start++;
            token = LithiumConfigTokenTypes.BRACE;
            return;
        }

        start++;
        token = LithiumConfigTokenTypes.OPERATOR;
    }

    @Override public @NotNull CharSequence getBufferSequence() { return buffer; }
    @Override public int getBufferEnd() { return end; }
}