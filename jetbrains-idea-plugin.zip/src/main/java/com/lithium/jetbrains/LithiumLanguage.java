package com.lithium.jetbrains;

import com.intellij.lang.Language;

public final class LithiumLanguage extends Language {
    public static final LithiumLanguage INSTANCE = new LithiumLanguage();
    private LithiumLanguage() { super("Lithium"); }
}