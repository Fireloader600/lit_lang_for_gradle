package com.lithium.jetbrains;

import com.intellij.lexer.Lexer;
import com.intellij.openapi.editor.DefaultLanguageHighlighterColors;
import com.intellij.openapi.editor.colors.TextAttributesKey;
import com.intellij.openapi.fileTypes.SyntaxHighlighterBase;
import com.intellij.psi.tree.IElementType;
import org.jetbrains.annotations.NotNull;

import static com.intellij.openapi.editor.colors.TextAttributesKey.createTextAttributesKey;

public class LithiumConfigSyntaxHighlighter extends SyntaxHighlighterBase {

    public static final TextAttributesKey KEY =
        createTextAttributesKey("LITHIUM_CONFIG_KEY", DefaultLanguageHighlighterColors.INSTANCE_FIELD);
    public static final TextAttributesKey STRING =
        createTextAttributesKey("LITHIUM_CONFIG_STRING", DefaultLanguageHighlighterColors.STRING);
    public static final TextAttributesKey NUMBER =
        createTextAttributesKey("LITHIUM_CONFIG_NUMBER", DefaultLanguageHighlighterColors.NUMBER);
    public static final TextAttributesKey COMMENT =
        createTextAttributesKey("LITHIUM_CONFIG_COMMENT", DefaultLanguageHighlighterColors.LINE_COMMENT);
    public static final TextAttributesKey LITERAL =
        createTextAttributesKey("LITHIUM_CONFIG_LITERAL", DefaultLanguageHighlighterColors.KEYWORD);
    public static final TextAttributesKey OPERATOR =
        createTextAttributesKey("LITHIUM_CONFIG_OPERATOR", DefaultLanguageHighlighterColors.OPERATION_SIGN);
    public static final TextAttributesKey BRACE =
        createTextAttributesKey("LITHIUM_CONFIG_BRACE", DefaultLanguageHighlighterColors.BRACES);

    private static final TextAttributesKey[] KEY_KEYS   = { KEY };
    private static final TextAttributesKey[] STR_KEYS   = { STRING };
    private static final TextAttributesKey[] NUM_KEYS   = { NUMBER };
    private static final TextAttributesKey[] CMT_KEYS   = { COMMENT };
    private static final TextAttributesKey[] LIT_KEYS   = { LITERAL };
    private static final TextAttributesKey[] OP_KEYS    = { OPERATOR };
    private static final TextAttributesKey[] BRACE_KEYS = { BRACE };
    private static final TextAttributesKey[] EMPTY      = new TextAttributesKey[0];

    @NotNull @Override
    public Lexer getHighlightingLexer() { return new LithiumConfigLexer(); }

    @NotNull @Override
    public TextAttributesKey[] getTokenHighlights(IElementType t) {
        if (t == LithiumConfigTokenTypes.KEY)      return KEY_KEYS;
        if (t == LithiumConfigTokenTypes.STRING)   return STR_KEYS;
        if (t == LithiumConfigTokenTypes.NUMBER)   return NUM_KEYS;
        if (t == LithiumConfigTokenTypes.COMMENT)  return CMT_KEYS;
        if (t == LithiumConfigTokenTypes.LITERAL)  return LIT_KEYS;
        if (t == LithiumConfigTokenTypes.OPERATOR) return OP_KEYS;
        if (t == LithiumConfigTokenTypes.BRACE)    return BRACE_KEYS;
        return EMPTY;
    }
}