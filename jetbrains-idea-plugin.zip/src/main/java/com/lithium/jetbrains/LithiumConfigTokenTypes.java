package com.lithium.jetbrains;

import com.intellij.psi.tree.IElementType;

public final class LithiumConfigTokenTypes {
    private LithiumConfigTokenTypes() {}

    public static final IElementType KEY      = new LithiumConfigTokenType("KEY");
    public static final IElementType STRING   = new LithiumConfigTokenType("STRING");
    public static final IElementType NUMBER   = new LithiumConfigTokenType("NUMBER");
    public static final IElementType COMMENT  = new LithiumConfigTokenType("COMMENT");
    public static final IElementType LITERAL  = new LithiumConfigTokenType("LITERAL");
    public static final IElementType OPERATOR = new LithiumConfigTokenType("OPERATOR");
    public static final IElementType BRACE    = new LithiumConfigTokenType("BRACE");
}