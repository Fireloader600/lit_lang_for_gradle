package com.lithium.jetbrains;

import com.intellij.openapi.fileTypes.LanguageFileType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;

public final class LithiumConfigFileType extends LanguageFileType {
    public static final LithiumConfigFileType INSTANCE = new LithiumConfigFileType();

    private LithiumConfigFileType() { super(LithiumConfigLanguage.INSTANCE); }

    @NotNull @Override public String getName()             { return "Lithium Config File"; }
    @NotNull @Override public String getDescription()      { return "Lithium 配置文件"; }
    @NotNull @Override public String getDefaultExtension() { return "litc"; }
    @Nullable @Override public Icon getIcon()              { return null; }
}